<?php

// View Details for a Specific Company Account
function clm_company_details_page() {
    $accounts_details_url = admin_url('admin.php?page=clm-view-accounts');
    if (!isset($_GET['company_id'])) {
        echo '<div class="wrap"><p>' . __('Invalid company ID.', 'clm') . '</p></div>';
        return;
    }

    $company_id = intval($_GET['company_id']);
    $company_user = get_userdata($company_id);

    if (!$company_user || !in_array('company', $company_user->roles)) {
        echo '<div class="wrap"><p>' . __('Company account not found or invalid.', 'clm') . '</p></div>';
        return;
    }

    $company_name = $company_user->display_name;
    $registration_date = $company_user->user_registered;
    $licenses = get_user_meta($company_id, '_clm_licenses', true);

    echo '<div class="wrap">';
    echo '<a href="' . esc_url($accounts_details_url) . '" class="back-to-account-details" style="display: inline-block; margin-bottom: 20px;">&larr; ' . __('Back to Account Detail', 'clm') . '</a>';
    echo '<h1>' . esc_html($company_name) . ' - ' . __('Details', 'clm') . '</h1>';
    echo '<p>' . __('Registered on: ', 'clm') . esc_html(date('F j, Y', strtotime($registration_date))) . '</p>';
    echo '<p>' . __('Email: ', 'clm') . esc_html($company_user->user_email) . '</p>';

    if (!empty($licenses)) {
        foreach ($licenses as $course_id => $license_data) {
            $course_title = get_the_title($course_id);
            $remaining_licenses = $license_data['total'] - $license_data['used'];

            echo '<h3>' . esc_html($course_title) . '</h3>';
            echo '<p>' . __('Total Licenses: ', 'clm') . esc_html($license_data['total']) . '</p>';
            echo '<p>' . __('Licenses Used: ', 'clm') . esc_html($license_data['used']) . '</p>';
            echo '<p>' . __('Licenses Remaining: ', 'clm') . esc_html($remaining_licenses) . '</p>';

            // Dropdown for managing users
            $course_details_url = admin_url('admin.php?page=clm-course-details&parent_id=' . esc_attr($company_id) . '&course_id=' . esc_attr($course_id));
            echo '<a href="' . esc_url($course_details_url) . '" class="button button-secondary">' . __('View Details', 'clm') . '</a>';

            // Placeholder for user management actions
            echo '<div class="clm-user-management"></div>';
        }
    } else {
        echo '<p>' . __('No licenses found.', 'clm') . '</p>';
    }

    echo '</div>'; // Close wrap
}
