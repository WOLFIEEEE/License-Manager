<?php
// Add action to handle the form submission for admin
add_action('init', 'clm_handle_user_assignment_admin');

function clm_admin_assign_course_to_user($user_id, $course_id , $parent_id) {
    $enrolled = custom_enroll_user_in_course($user_id, $course_id);

    if ($enrolled) {
        $licenses = get_user_meta($parent_id, '_clm_licenses', true);
        $licenses[$course_id]['used'] += 1;
        update_user_meta($parent_id, '_clm_licenses', $licenses);

        // Retrieve the existing parent-course metadata
        $parent_course_data = get_user_meta($user_id, '_clm_parent_course_data', true);

        if (!is_array($parent_course_data)) {
            $parent_course_data = [];
        }

        // Append the new parent-course assignment
        $parent_course_data[] = [
            'parent_id' => $parent_id,
            'course_id' => $course_id,
        ];

        // Update the user meta with the new array
        update_user_meta($user_id, '_clm_parent_course_data', $parent_course_data);
        clm_admin_show_message('success', __('User has been successfully assigned to the course.', 'clm'));
    } else {
        error_log('CLM Error: Failed to assign the license to user ID ' . $user_id . ' for course ID ' . $course_id);
        clm_admin_show_message('error', __('Error Failed to Assign course.', 'clm'));
    }
}

function clm_get_or_create_user_admin($email, $first_name, $last_name , $parent_id) {
    $user = get_user_by('email', $email);

    if (!$user) {
        $user_id = wp_create_user($email, wp_generate_password(12, false), $email);

        if (is_wp_error($user_id)) {
            error_log('CLM Error: Failed to create user - ' . $user_id->get_error_message());
            clm_show_message('error', __('Failed to create user', 'clm'));
            return false;
        }

        wp_update_user([
            'ID' => $user_id,
            'first_name' => $first_name,
            'last_name' => $last_name
        ]);
        update_user_meta($user_id, '_clm_parent_user', $parent_id);

        $user = get_user_by('id', $user_id);
        error_log('CLM Info: New user created with ID - ' . $user_id);

        wp_new_user_notification($user_id, null, 'user');
    } else {
        if (!get_user_meta($user->ID, '_clm_parent_user', true)) {
            update_user_meta($user->ID, '_clm_parent_user',  $parent_id);
        }
    }

    return $user;
}

function clm_handle_user_assignment_admin() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'clm_add_user_to_course') {
        // Buffer output to prevent redirection
        ob_start();

        // Validate the nonce (you should add a nonce field to your form for security)
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'clm_add_user_nonce')) {
            clm_admin_show_message('error', __('Security check failed.', 'clm'));
            ob_end_flush();
            return;
        }

        // Sanitize and retrieve the form data
        $course_id = intval($_POST['course_id']);
        $user_id = intval($_POST['user_id']);
        $parent_id = intval($_POST['parent_id']);
        $first_name = sanitize_text_field($_POST['first_name']);
        $last_name = sanitize_text_field($_POST['last_name']);
        $email = sanitize_email($_POST['email']);
        $confirm_email = sanitize_email($_POST['confirm_email']);

        // Validate the email and confirm email match
        if ($email !== $confirm_email) {
            clm_admin_show_message('error', __('Email and Confirm Email do not match.', 'clm'));
            ob_end_flush();
            return;
        }

        // Check if the email is valid
        if (!is_email($email)) {
            clm_admin_show_message('error', __('Invalid email address.', 'clm'));
            ob_end_flush();
            return;
        }

        // Get or create the user
        $user = clm_get_or_create_user_admin($email, $first_name, $last_name, $parent_id);

        if (!$user) {
            clm_admin_show_message('error', __('Error creating or retrieving the user.', 'clm'));
            ob_end_flush();
            return;
        }

        // Check if the user is already enrolled in the course
        if (clm_is_user_already_enrolled($user->ID, $course_id)) {
            clm_admin_show_message('error', __('User is already enrolled in the Course.', 'clm'));
            ob_end_flush();
            return;
        }

        // Assign the course to the user
        clm_admin_assign_course_to_user($user->ID, $course_id , $parent_id);
        // Display a success message
        
        // Output the buffered content
        ob_end_flush();
    }
}



// Function to display admin messages at the top of the page
function clm_admin_show_message($type, $message) {
    add_action('admin_notices', function() use ($type, $message) {
        $class = ($type === 'error') ? 'notice notice-error' : 'notice notice-success';
        echo '<div class="' . esc_attr($class) . ' is-dismissible"><p>' . esc_html($message) . '</p></div>';
    });
}

// View Sub-Accounts for a Specific Course
function clm_course_details_page() {

    // Ensure that course_id and parent_id are provided in the URL
    if (!isset($_GET['course_id']) || !isset($_GET['parent_id'])) {
        echo '<div class="wrap"><p>' . __('Invalid course or parent ID.', 'clm') . '</p></div>';
        return;
    }

    $course_id = intval($_GET['course_id']);
    $parent_id = intval($_GET['parent_id']);
    $course_title = get_the_title($course_id);

    // Get the parent user data based on the provided parent_id
    $parent_user = get_userdata($parent_id);
    if (!$parent_user) {
        echo '<div class="wrap"><p>' . __('Parent account not found or invalid.', 'clm') . '</p></div>';
        return;
    }

    // Display course and parent details
    echo '<div class="wrap">';
    $company_details_url = admin_url('admin.php?page=clm-company-details&company_id=' . esc_attr($parent_id));
    echo '<a href="' . esc_url($company_details_url) . '" class="back-to-company-detail" style="display: inline-block; margin-bottom: 20px;">&larr; ' . __('Back to Company Details', 'clm') . '</a>';
    echo '<h1>' . esc_html($course_title) . ' - ' . __('Sub Accounts', 'clm') . '</h1>';
    echo '<p>' . __('Parent User: ', 'clm') . esc_html($parent_user->display_name) . '</p>';
    echo '<p>' . __('Parent ID: ', 'clm') . esc_html($parent_user->ID) . '</p>';
    echo '<p>' . __('Parent Email: ', 'clm') . esc_html($parent_user->user_email) . '</p>';
    echo '<p>' . __('Course ID: ', 'clm') . esc_html($course_id) . '</p>';

    // Retrieve license data from user meta
    $license_data = get_user_meta($parent_user->ID, '_clm_licenses', true)[$course_id];

    // Check if the license data exists
    if (!empty($license_data)) {
        $total_licenses = isset($license_data['total']) ? $license_data['total'] : 0;
        $used_licenses = isset($license_data['used']) ? $license_data['used'] : 0;
        $remaining_licenses = $total_licenses - $used_licenses;

        echo '<p>' . __('Licenses Bought: ', 'clm') . esc_html($total_licenses) . '</p>';
        echo '<p>' . __('Licenses Used: ', 'clm') . esc_html($used_licenses) . '</p>';
        echo '<p>' . __('Licenses Left: ', 'clm') . esc_html($remaining_licenses) . '</p>';
    } else {
        echo '<p>' . __('No license information available.', 'clm') . '</p>';
    }


    // Add User Button
    echo '<button id="clm-add-user-button" class="button button-primary">' . __('Add User', 'clm') . '</button>';

    // Form HTML (initially hidden)
    echo '<div id="clm-add-user-form" style="display:none; margin-top: 20px;">';
    echo '<form method="post" action="" style="display: flex; flex-wrap: wrap;">';
    echo '<input type="hidden" name="action" value="clm_add_user_to_course">';
    echo '<input type="hidden" name="course_id" value="' . esc_attr($course_id) . '">';
    echo '<input type="hidden" name="parent_id" value="' . esc_attr($parent_id) . '">';
    wp_nonce_field('clm_add_user_nonce'); // Nonce field for security
    
    echo '<div style="flex: 1; min-width: 200px; margin-right: 20px;">';
    echo '<p style="margin: 0;"><label for="first_name">' . __('First Name', 'clm') . '</label>';
    echo '<input type="text" name="first_name" id="first_name" required style="width: 100%; margin-bottom: 10px;"></p>';
    echo '</div>';
    
    echo '<div style="flex: 1; min-width: 200px;">';
    echo '<p style="margin: 0;"><label for="last_name">' . __('Last Name', 'clm') . '</label>';
    echo '<input type="text" name="last_name" id="last_name" required style="width: 100%; margin-bottom: 10px;"></p>';
    echo '</div>';

    // Email field in the second row
    echo '<div style="flex-basis: 100%; margin-top: 10px;">';
    echo '<p style="margin: 0;"><label for="email" style="display: block;">' . __('Email', 'clm') . '</label>';
    echo '<input type="email" name="email" id="email" required style="width: 50%; margin-bottom: 10px;"></p>';
    echo '</div>';
    
    // Confirm Email field in the third row
    echo '<div style="flex-basis: 100%; margin-top: 10px;">';
    echo '<p style="margin: 0;"><label for="confirm_email" style="display: block;">' . __('Confirm Email', 'clm') . '</label>';
    echo '<input type="email" name="confirm_email" id="confirm_email" required style="width: 50%; margin-bottom: 10px;"></p>';
    echo '</div>';



    // Submit Button
    echo '<div style="flex-basis: 100%; margin-top: 15px;">';
    echo '<button type="submit" class="button button-primary" style="width: auto;">' . __('Assign', 'clm') . '</button>';
    echo '</div>';

    echo '</form>';
    echo '</div>';

    // Fetch the sub-accounts associated with the parent user for this specific course
    $sub_accounts = clm_get_sub_accounts($parent_id, $course_id);

    if (!empty($sub_accounts)) {
        // Display sub-accounts in a table
        echo '<table class="wp-list-table widefat fixed striped table-view-list" style="margin-top: 20px;">';
        echo '<thead><tr><th>' . __('First Name', 'clm') . '</th><th>' . __('Last Name', 'clm') . '</th><th>' . __('Email', 'clm') . '</th><th>' . __('Registered On', 'clm') . '</th><th>' . __('Actions', 'clm') . '</th></tr></thead>';
        echo '<tbody>';

        foreach ($sub_accounts as $sub_account) {
            echo '<tr>';
            echo '<td>' . esc_html($sub_account->first_name) . '</td>';
            echo '<td>' . esc_html($sub_account->last_name) . '</td>';
            echo '<td>' . esc_html($sub_account->user_email) . '</td>';
            echo '<td>' . esc_html(date('F j, Y', strtotime($sub_account->user_registered))) . '</td>';
            echo '<td><a href="' . esc_url(admin_url('admin-post.php?action=clm_remove_user&user_id=' . esc_attr($sub_account->ID) . '&course_id=' . esc_attr($course_id) . '&parent_id=' . esc_attr($parent_id))) . '" class="button clm-remove-user" onclick="return confirm(\'Are you sure you want to remove this user from the course?\');">' . __('Remove User', 'clm') . '</a></td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
    } else {
        echo '<p>' . __('No sub-accounts found for this course.', 'clm') . '</p>';
    }

    echo '</div>'; // Close wrap

    // JavaScript for showing the form
    ?>
    <script type="text/javascript">
        document.getElementById('clm-add-user-button').addEventListener('click', function() {
            var form = document.getElementById('clm-add-user-form');
            if (form.style.display === 'none' || form.style.display === '') {
                form.style.display = 'block';
            } else {
                form.style.display = 'none';
            }
        });
    </script>
    <?php
}
?>
