<?php

// Add the Company License Manager settings menu
function clm_admin_menu() {
    add_menu_page(
        'Company License Manager',
        'License Manager',
        'manage_options',
        'clm-settings',
        'clm_settings_page',
        'dashicons-admin-users',
        100
    );

    // Add submenu for viewing company accounts
    add_submenu_page(
        'clm-settings',
        'View Company Accounts',
        'Company Accounts',
        'manage_options',
        'clm-view-accounts',
        'clm_view_accounts_page'
    );

    add_submenu_page(
        null, // Parent slug (null because it's hidden)
        'Company Details',
        'Company Details',
        'manage_options',
        'clm-company-details',
        'clm_company_details_page' // Ensure this matches exactly with the function name
    );

    add_submenu_page(
        null, // Hidden parent slug because we want to access directly
        'Course Details',
        'Course Details',
        'manage_options', // Empty capability since we're removing it
        'clm-course-details',
        'clm_course_details_page'
    );

}
add_action('admin_menu', 'clm_admin_menu');

function clm_enqueue_ajax_scripts() {
    wp_enqueue_script('clm-ajax-script', plugins_url('/assets/js/clm-ajax.js', __FILE__), array('jquery'), null, true);
    wp_localize_script('clm-ajax-script', 'clm_ajax_object', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('clm_ajax_nonce'),
    ));
}
add_action('admin_enqueue_scripts', 'clm_enqueue_ajax_scripts');

