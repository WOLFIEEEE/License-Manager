<?php

// Register settings
// Register settings
// Register settings
function clm_register_settings() {
    // Register all the necessary options
    register_setting('clm_settings_group', 'clm_license_email_subject', ['default' => __('Course Assignment: You Have %d Licenses Available for %s', 'clm')]);
    register_setting('clm_settings_group', 'clm_license_email_template', [
        'default' => "<div style='font-family: Arial, sans-serif; color: #333; max-width: 600px; margin: 0 auto;'>
            <div style='padding: 20px; background-color: #f5f5f5; border-bottom: 3px solid #004078;'>
                <h2 style='color: green; text-align: center;'>Congratulations!</h2>
                <p style='text-align: center;'>You have successfully purchased <strong>{license_count}</strong> licenses for the <strong>{course_name}</strong> course.</p>
            </div>
            <div style='padding: 20px;'>
                <p>You can manage your sub-accounts and assign courses using the link below:</p>
                <p style='text-align: center; margin-top: 20px;'>
                    <a href='{site_url}' style='background-color: #004078; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Manage Your Licenses</a>
                </p>
                <p style='margin-top: 30px;'>Here are the steps you need to follow, or you can use the direct link provided:</p>
                <ol style='color: #004078; padding-left: 20px;'>
                    <li>Open the site: <a href='{site_home_url}' style='color: #004078;'>{site_home_url}</a></li>
                    <li>Login using your valid credentials.</li>
                    <li>Go to the <strong>My Accounts</strong> section.</li>
                    <li>Open the <strong>Manage Account</strong> page.</li>
                    <li>You will see the course you purchased and the total count of licenses. You can select a course from the dropdown if you purchased licenses for different courses.</li>
                    <li>Enter the <strong>First Name</strong>, <strong>Last Name</strong>, <strong>Email</strong>, and <strong>Confirm Email</strong>.</li>
                    <li>Click the <strong>Assign</strong> button to assign the course to the user.</li>
                </ol>
                <div style='margin-top: 30px; padding: 20px; background-color: #f5f5f5; border-left: 4px solid darkred;'>
                    <h3 style='color: darkred;'>Important:</h3>
                    <ul style='padding-left: 20px;'>
                        <li>Please confirm the details twice before sending the invitation. Once assigned, it cannot be altered or reversed.</li>
                        <li>Upon successful assignment, the user will receive an email with credentials to access the course.</li>
                    </ul>
                </div>
                <p style='margin-top: 30px;'>Thank you for purchasing the course!</p>
                <p>Best regards,</p>
                <p><strong>{site_owner_name}</strong></p>
                <p><a href='{site_home_url}' style='color: #004078;'>{site_home_url}</a></p>
            </div>
        </div>"
    ]);
    
    register_setting('clm_settings_group', 'clm_enrollment_email_subject', ['default' => __('You have been enrolled in %s!', 'clm')]);
    register_setting('clm_settings_group', 'clm_enrollment_email_template', [
        'default' => "<div style='font-family: Arial, sans-serif; color: #333; max-width: 600px; margin: 0 auto;'>
            <div style='background-color: #004078; padding: 20px; text-align: center; color: #fff;'>
                <h2 style='font-size: 24px;'>Welcome to <strong>{course_name}</strong></h2>
                <p style='margin-top: 10px; font-style: italic;'>By {site_owner_name}</p>
            </div>
            <div style='padding: 20px;'>
                <p>Dear <strong>{user_name}</strong>,</p>
                <p>You have been successfully enrolled in the <strong style='color: #004078;'>{course_name}</strong> course, thanks to <strong>{parent_name}</strong>.</p>
                <p style='margin-top: 20px;'>
                    To start your learning journey, please set your password using the link below. This will allow you to access your course materials and begin exploring the content we've prepared for you.
                </p>
                <p style='text-align: center; margin-top: 20px;'>
                    <a href='{reset_url}' style='background-color: #28a745; color: #fff; padding: 15px 25px; text-decoration: none; border-radius: 5px; font-size: 16px;'>Set Your New Password</a>
                </p>
                <p style='margin-top: 10px;'>
                    If the button above doesn't work, please use the following link: <a href='{reset_url}' style='color: #004078;'>{reset_url}</a>
                </p>
                <p style='margin-top: 20px;'>
                    <strong>Note:</strong> If you have already set your password or are a registered user, you can simply log in using your existing password.
                </p>
                <p style='margin-top: 30px; border-top: 1px solid #ddd; padding-top: 20px;'>
                    <strong>Your Login Details:</strong>
                    <br><br>
                    <strong>Username:</strong> {user_login}
                    <br>
                    <strong>Password:</strong> 
                    <br>
                    You can use either the new password you set or your existing password to log in.
                </p>
                <p style='margin-top: 30px; border-top: 1px solid #ddd; padding-top: 20px;'>
                    <strong>How to Access Your Course:</strong>
                    <br><br>
                    1. <a href='" . wp_login_url() . "' style='color: #004078;'>Log in</a> to your account using your username and the new password you set.
                    <br>
                    2. Navigate to the 'My Courses' section.
                    <br>
                    3. Select the <strong>{course_name}</strong> course and start learning.
                </p>
                <p style='margin-top: 30px; border-top: 1px solid #ddd; padding-top: 20px;'>
                    <strong>Need Assistance?</strong>
                    <br><br>
                    If you encounter any issues or have any questions, please don't hesitate to <a href='mailto:<?php echo $admin_email; ?>' style='color: #004078;'>contact our site administrator</a>. We're here to help you every step of the way.
                </p>
                <p style='margin-top: 30px; border-top: 1px solid #ddd; padding-top: 20px;'>
                    Best regards,
                    <br>
                    <strong>{site_owner_name}</strong>
                    <br>
                    <a href='{site_home_url}' style='color: #004078;'>{site_home_url}</a>
                </p>
            </div>
            <div style='background-color: #f5f5f5; padding: 10px; text-align: center; margin-top: 40px;'>
                <p style='color: #777;'>Powered by Your Site Name</p>
            </div>
        </div>"
    ]);

    register_setting('clm_settings_group', 'clm_site_owner_name', ['default' => 'Kris Rivernberg']);
    register_setting('clm_settings_group', 'clm_site_home_url', ['default' => site_url()]);
    register_setting('clm_settings_group', 'clm_manage_accounts_url', ['default' => site_url('/manage-accounts')]);

    // Add settings section and fields
    add_settings_section('clm_main_section', __('Main Settings', 'clm'), null, 'clm-settings');

    add_settings_field('clm_site_owner_name', __('Site Owner Name', 'clm'), 'clm_site_owner_name_callback', 'clm-settings', 'clm_main_section');
    add_settings_field('clm_site_home_url', __('Site Home URL', 'clm'), 'clm_site_home_url_callback', 'clm-settings', 'clm_main_section');
    add_settings_field('clm_manage_accounts_url', __('Manage Accounts URL', 'clm'), 'clm_manage_accounts_url_callback', 'clm-settings', 'clm_main_section');

    add_settings_field('clm_license_email_subject', __('License Email Subject', 'clm'), 'clm_license_email_subject_callback', 'clm-settings', 'clm_main_section');
    add_settings_field('clm_license_email_template', __('License Email Template', 'clm'), 'clm_license_email_template_callback', 'clm-settings', 'clm_main_section');

    add_settings_field('clm_enrollment_email_subject', __('Enrollment Email Subject', 'clm'), 'clm_enrollment_email_subject_callback', 'clm-settings', 'clm_main_section');
    add_settings_field('clm_enrollment_email_template', __('Enrollment Email Template', 'clm'), 'clm_enrollment_email_template_callback', 'clm-settings', 'clm_main_section');
}
add_action('admin_init', 'clm_register_settings');


// Settings field callbacks

// Site owner name callback
function clm_site_owner_name_callback() {
    $value = get_option('clm_site_owner_name', 'Kris Rivernberg');
    echo '<input type="text" name="clm_site_owner_name" value="' . esc_attr($value) . '" class="regular-text">';
    echo '<p class="description">Enter the site owner\'s name.</p>';
}

// Site Home URL callback
function clm_site_home_url_callback() {
    $value = get_option('clm_site_home_url', site_url());
    echo '<input type="url" name="clm_site_home_url" value="' . esc_attr($value) . '" class="regular-text">';
    echo '<p class="description">Enter the home URL of the site.</p>';
}

// Manage Accounts URL callback
function clm_manage_accounts_url_callback() {
    $value = get_option('clm_manage_accounts_url', site_url('/manage-accounts'));
    echo '<input type="url" name="clm_manage_accounts_url" value="' . esc_attr($value) . '" class="regular-text">';
    echo '<p class="description">Enter the URL for managing accounts.</p>';
}

// License email subject callback
function clm_license_email_subject_callback() {
    $value = get_option('clm_license_email_subject', __('Course Assignment: You Have %d Licenses Available for %s', 'clm'));
    echo '<input type="text" name="clm_license_email_subject" value="' . esc_attr($value) . '" class="regular-text">';
    echo '<p class="description">Customize the subject for license emails. Use {license_count} and {course_name} as placeholders.</p>';
}

// License email template callback
function clm_license_email_template_callback() {
    $value = get_option('clm_license_email_template', "<div style='font-family: Arial, sans-serif; color: #333; max-width: 600px; margin: 0 auto;'>
        <div style='padding: 20px; background-color: #f5f5f5; border-bottom: 3px solid #004078;'>
            <h2 style='color: green; text-align: center;'>Congratulations!</h2>
            <p style='text-align: center;'>You have successfully purchased <strong>{license_count}</strong> licenses for the <strong>{course_name}</strong> course.</p>
        </div>
        <div style='padding: 20px;'>
            <p>You can manage your sub-accounts and assign courses using the link below:</p>
            <p style='text-align: center; margin-top: 20px;'>
                <a href='{site_url}' style='background-color: #004078; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Manage Your Licenses</a>
            </p>
            <p style='margin-top: 30px;'>Here are the steps you need to follow, or you can use the direct link provided:</p>
            <ol style='color: #004078; padding-left: 20px;'>
                <li>Open the site: <a href='{site_home_url}' style='color: #004078;'>{site_home_url}</a></li>
                <li>Login using your valid credentials.</li>
                <li>Go to the <strong>My Accounts</strong> section.</li>
                <li>Open the <strong>Manage Account</strong> page.</li>
                <li>You will see the course you purchased and the total count of licenses. You can select a course from the dropdown if you purchased licenses for different courses.</li>
                <li>Enter the <strong>First Name</strong>, <strong>Last Name</strong>, <strong>Email</strong>, and <strong>Confirm Email</strong>.</li>
                <li>Click the <strong>Assign</strong> button to assign the course to the user.</li>
            </ol>
            <div style='margin-top: 30px; padding: 20px; background-color: #f5f5f5; border-left: 4px solid darkred;'>
                <h3 style='color: darkred;'>Important:</h3>
                <ul style='padding-left: 20px;'>
                    <li>Please confirm the details twice before sending the invitation. Once assigned, it cannot be altered or reversed.</li>
                    <li>Upon successful assignment, the user will receive an email with credentials to access the course.</li>
                </ul>
            </div>
            <p style='margin-top: 30px;'>Thank you for purchasing the course!</p>
            <p>Best regards,</p>
            <p><strong>{site_owner_name}</strong></p>
            <p><a href='{site_home_url}' style='color: #004078;'>{site_home_url}</a></p>
        </div>
    </div>");
    echo '<textarea name="clm_license_email_template" class="large-text code" rows="15">' . esc_textarea($value) . '</textarea>';
    echo '<p class="description">Customize the license email template. Use {license_count}, {course_name}, {site_url}, {site_owner_name}, and {site_home_url} as placeholders.</p>';
}

// Enrollment email subject callback
function clm_enrollment_email_subject_callback() {
    $value = get_option('clm_enrollment_email_subject', __('You have been enrolled in %s!', 'clm'));
    echo '<input type="text" name="clm_enrollment_email_subject" value="' . esc_attr($value) . '" class="regular-text">';
    echo '<p class="description">Customize the subject for enrollment emails. Use {course_name} as a placeholder.</p>';
}

// Enrollment email template callback
function clm_enrollment_email_template_callback() {
    $value = get_option('clm_enrollment_email_template', "<div style='font-family: Arial, sans-serif; color: #333; max-width: 600px; margin: 0 auto;'>
        <div style='background-color: #004078; padding: 20px; text-align: center; color: #fff;'>
            <h2 style='font-size: 24px;'>Welcome to <strong>{course_name}</strong></h2>
            <p style='margin-top: 10px; font-style: italic;'>By {site_owner_name}</p>
        </div>
        <div style='padding: 20px;'>
            <p>Dear <strong>{user_name}</strong>,</p>
            <p>You have been successfully enrolled in the <strong style='color: #004078;'>{course_name}</strong> course, thanks to <strong>{parent_name}</strong>.</p>
            <p style='margin-top: 20px;'>
                To start your learning journey, please set your password using the link below. This will allow you to access your course materials and begin exploring the content we've prepared for you.
            </p>
            <p style='text-align: center; margin-top: 20px;'>
                <a href='{reset_url}' style='background-color: #28a745; color: #fff; padding: 15px 25px; text-decoration: none; border-radius: 5px; font-size: 16px;'>Set Your New Password</a>
            </p>
            <p style='margin-top: 10px;'>
                If the button above doesn't work, please use the following link: <a href='{reset_url}' style='color: #004078;'>{reset_url}</a>
            </p>
            <p style='margin-top: 20px;'>
                <strong>Note:</strong> If you have already set your password or are a registered user, you can simply log in using your existing password.
            </p>
            <p style='margin-top: 30px; border-top: 1px solid #ddd; padding-top: 20px;'>
                <strong>Your Login Details:</strong>
                <br><br>
                <strong>Username:</strong> {user_login}
                <br>
                <strong>Password:</strong> 
                <br>
                You can use either the new password you set or your existing password to log in.
            </p>
            <p style='margin-top: 30px; border-top: 1px solid #ddd; padding-top: 20px;'>
                <strong>How to Access Your Course:</strong>
                <br><br>
                1. <a href='" . wp_login_url() . "' style='color: #004078;'>Log in</a> to your account using your username and the new password you set.
                <br>
                2. Navigate to the 'My Courses' section.
                <br>
                3. Select the <strong>{course_name}</strong> course and start learning.
            </p>
            <p style='margin-top: 30px; border-top: 1px solid #ddd; padding-top: 20px;'>
                <strong>Need Assistance?</strong>
                <br><br>
                If you encounter any issues or have any questions, please don't hesitate to <a href='mailto:<?php echo $admin_email; ?>' style='color: #004078;'>contact our site administrator</a>. We're here to help you every step of the way.
            </p>
            <p style='margin-top: 30px; border-top: 1px solid #ddd; padding-top: 20px;'>
                Best regards,
                <br>
                <strong>{site_owner_name}</strong>
                <br>
                <a href='{site_home_url}' style='color: #004078;'>{site_home_url}</a>
            </p>
        </div>
        <div style='background-color: #f5f5f5; padding: 10px; text-align: center; margin-top: 40px;'>
            <p style='color: #777;'>Powered by Your Site Name</p>
        </div>
    </div>");
    echo '<textarea name="clm_enrollment_email_template" class="large-text code" rows="15">' . esc_textarea($value) . '</textarea>';
    echo '<p class="description">Customize the enrollment email template. Use {user_name}, {course_name}, {user_login}, {password}, {reset_url}, {site_url}, {parent_name}, {site_owner_name}, and {site_home_url} as placeholders.</p>';
}


function clm_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php _e('Company License Manager Settings', 'clm'); ?></h1>
        
        <!-- Tab Navigation -->
        <h2 class="nav-tab-wrapper">
            <a href="#template-editor" class="nav-tab nav-tab-active"><?php _e('Template Editor', 'clm'); ?></a>
            <a href="#template-preview" class="nav-tab"><?php _e('Template Preview', 'clm'); ?></a>
        </h2>

        <!-- Tab Content -->
        <div id="template-editor" class="tab-content">
            <form method="post" action="options.php">
                <?php
                settings_fields('clm_settings_group');
                do_settings_sections('clm-settings');
                submit_button();
                ?>
            </form>
        </div>
        <div id="template-preview" class="tab-content" style="display: none;">
            <h2><?php _e('Preview of License Email Template', 'clm'); ?></h2>
            <div id="license-email-preview" style="border: 1px solid #ddd; padding: 20px;">
                <!-- The preview content will be dynamically inserted here -->
            </div>

            <h2 style="margin-top: 40px;"><?php _e('Preview of Enrollment Email Template', 'clm'); ?></h2>
            <div id="enrollment-email-preview" style="border: 1px solid #ddd; padding: 20px;">
                <!-- The preview content will be dynamically inserted here -->
            </div>
        </div>

        <script>
            // Tab Switching Logic
            document.addEventListener('DOMContentLoaded', function() {
                const tabs = document.querySelectorAll('.nav-tab');
                const tabContents = document.querySelectorAll('.tab-content');

                tabs.forEach(function(tab) {
                    tab.addEventListener('click', function(e) {
                        e.preventDefault();

                        tabs.forEach(function(t) {
                            t.classList.remove('nav-tab-active');
                        });

                        tab.classList.add('nav-tab-active');

                        tabContents.forEach(function(content) {
                            content.style.display = 'none';
                        });

                        const activeTab = tab.getAttribute('href');
                        document.querySelector(activeTab).style.display = 'block';

                        // Update the preview when switching to the preview tab
                        if (activeTab === '#template-preview') {
                            updatePreview();
                        }
                    });
                });
            });

            // Function to update the previews
            function updatePreview() {
                const licenseTemplate = document.querySelector('[name="clm_license_email_template"]').value;
                const enrollmentTemplate = document.querySelector('[name="clm_enrollment_email_template"]').value;

                // Replace placeholders with dummy data for preview
                const previewLicenseTemplate = licenseTemplate.replace(/{license_count}/g, '5')
                    .replace(/{course_name}/g, 'Sample Course')
                    .replace(/{site_url}/g, '<?php echo site_url(); ?>')
                    .replace(/{site_owner_name}/g, 'Kris Rivernberg')
                    .replace(/{site_home_url}/g, '<?php echo site_url(); ?>');

                const previewEnrollmentTemplate = enrollmentTemplate.replace(/{user_name}/g, 'John Doe')
                    .replace(/{course_name}/g, 'Sample Course')
                    .replace(/{user_login}/g, 'john.doe')
                    .replace(/{password}/g, 'password123')
                    .replace(/{reset_url}/g, '<?php echo site_url('/reset-password'); ?>')
                    .replace(/{parent_name}/g, 'Jane Doe')
                    .replace(/{site_url}/g, '<?php echo site_url(); ?>')
                    .replace(/{site_owner_name}/g, 'Kris Rivernberg')
                    .replace(/{site_home_url}/g, '<?php echo site_url(); ?>');

                // Insert the preview content into the preview divs
                document.getElementById('license-email-preview').innerHTML = previewLicenseTemplate;
                document.getElementById('enrollment-email-preview').innerHTML = previewEnrollmentTemplate;
            }
        </script>

        <style>
            .tab-content {
                margin-top: 20px;
            }
        </style>
    </div>
    <?php
}
