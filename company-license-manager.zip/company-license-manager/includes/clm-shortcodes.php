<?php

// Shortcode for managing accounts
// Shortcode for managing accounts
add_shortcode('clm_company_manage_accounts', 'clm_company_manage_accounts_dashboard');


function clm_add_manage_account_menu_item($items) {
    $user = wp_get_current_user();

    if (in_array('company', (array) $user->roles)) {
        error_log('Company role detected. Adding Manage Account menu item.');

        $logout = $items['customer-logout'];
        unset($items['customer-logout']);

        $items['manage-account'] = __('Manage Sub-Accounts', 'clm');
        $items['customer-logout'] = $logout;
    }

    return $items;
}
add_filter('woocommerce_account_menu_items', 'clm_add_manage_account_menu_item');


function clm_company_manage_accounts_dashboard() {
    if (current_user_can('company')) {
        $user_id = get_current_user_id();
        $licenses = get_user_meta($user_id, '_clm_licenses', true);

        echo '<div class="clm-dashboard">';

        if (!empty($licenses)) {
            echo '<div class="clm-course-cards">';
            foreach ($licenses as $course_id => $license_data) {       
                display_course_details($course_id, $license_data, $user_id);
            }
            echo '</div>';
        } else {
            echo '<p>' . __('No licenses found.', 'clm') . '</p>';
        }

        // Hidden form
        echo '<form id="clm-hidden-form" method="post" style="display:none;">';
        echo '<input type="hidden" name="clm_course_id" id="clm_course_id">';
        echo '<input type="hidden" name="clm_user_email" id="clm_user_email">';
        echo '<input type="hidden" name="clm_user_first_name" id="clm_user_first_name">';
        echo '<input type="hidden" name="clm_user_last_name" id="clm_user_last_name">';
        echo '<input type="hidden" name="action" value="clm_assign_license">';
        echo wp_nonce_field('clm_assign_license_nonce', '_clm_nonce');
        echo '</form>';

        echo '</div>';

        // Adding JavaScript for the dialog and course selection
        ?>
        <script>
                document.addEventListener('DOMContentLoaded', function() {
    setupAssignButtons();
    setupViewDetailsButtons();

    function setupAssignButtons() {
        const addUserButtons = document.querySelectorAll('.clm-add-user-btn');
        addUserButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                const courseId = this.getAttribute('data-course-id');
                const courseName = this.getAttribute('data-course-title');
                const dialogContent = `
                   <div class="clm-dialog-overlay" tabindex="-1" role="dialog" aria-labelledby="clm-dialog-title" aria-describedby="clm-dialog-desc" aria-modal="true">
                    <div class="clm-dialog">
                        <h3 id="clm-dialog-title">Assign License - ${courseName}</h3>
                        <p id="clm-dialog-desc">Once assigned, the license is used and cannot be altered. Contact admin if you need further help.</p>
                        <form id="clm-dialog-form">
                            <label for="clm-first-name">First Name</label>
                            <input type="text" id="clm-first-name" required><br>
                            <label for="clm-last-name">Last Name</label>
                            <input type="text" id="clm-last-name" required><br>
                            <label for="clm-email">Email</label>
                            <input type="email" id="clm-email" required><br>
                            <label for="clm-confirm-email">Confirm Email</label>
                            <input type="email" id="clm-confirm-email" required><br>
                            <button type="submit">Assign License</button>
                            <button type="button" id="clm-cancel-btn">Cancel</button>
                        </form>
                    </div>
                    <div id="clm-live-region" class="visually-hidden" aria-live="assertive" aria-atomic="true"></div>
                </div>
                `;

                document.body.insertAdjacentHTML('beforeend', dialogContent);

                // Make background content inert
                document.querySelector('body > *:not(.clm-dialog-overlay)').inert = true;

                const dialogOverlay = document.querySelector('.clm-dialog-overlay');
                const firstInput = document.getElementById('clm-first-name');
                const cancelBtn = document.getElementById('clm-cancel-btn');
                const liveRegion = document.querySelector('#clm-live-region');


                // Set focus to the first input field
                firstInput.focus();

                // Trap focus within the dialog
                dialogOverlay.addEventListener('keydown', function(e) {
                    const focusableElements = dialogOverlay.querySelectorAll('input, button');
                    const firstFocusableElement = focusableElements[0];
                    const lastFocusableElement = focusableElements[focusableElements.length - 1];

                    if (e.key === 'Tab') {
                        if (e.shiftKey) {
                            if (document.activeElement === firstFocusableElement) {
                                e.preventDefault();
                                lastFocusableElement.focus();
                            }
                        } else {
                            if (document.activeElement === lastFocusableElement) {
                                e.preventDefault();
                                firstFocusableElement.focus();
                            }
                        }
                    }
                    if (e.key === 'Escape') {
                        closeDialog();
                    }
                });

                cancelBtn.addEventListener('click', closeDialog);

                function closeDialog() {
                    dialogOverlay.remove();
                    // Restore background content's interactivity
                    document.querySelector('body > *:not(.clm-dialog-overlay)').inert = false;
                    button.focus();
                }

                document.getElementById('clm-dialog-form').addEventListener('submit', function(e) {
                    e.preventDefault();

                    const firstName = firstInput.value.trim();
                    const lastName = document.getElementById('clm-last-name').value.trim();
                    const email = document.getElementById('clm-email').value.trim();
                    const confirmEmail = document.getElementById('clm-confirm-email').value.trim();

                    if (email !== confirmEmail) {
                        alert('Email and Confirm Email do not match.');
                        return;
                    }

                    // Show loading icon and message
                    const loadingContent = `
                        <div class="clm-loading" role="alert" aria-live="assertive">
                            <img src="wp-content/plugins/company-license-manager/assets/icons8-loading-color-96.png" width="50" height="50" alt="Loading icon" class="loading-icon">
                            <div class="loading-text">
                                <span>Assigning License...</span>
                                <p>(It may take a little time as it is creating a new user and assigning the license)</p>
                            </div>
                        </div>
                    `;

                    document.querySelector('.clm-dialog').innerHTML = loadingContent;

                    setTimeout(function() {
                        document.getElementById('clm_course_id').value = courseId;
                        document.getElementById('clm_user_first_name').value = firstName;
                        document.getElementById('clm_user_last_name').value = lastName;
                        document.getElementById('clm_user_email').value = email;
                        document.getElementById('clm-hidden-form').submit();
                    }, 1000); // Simulate loading time
                });
            });
        });
    }

    function setupViewDetailsButtons() {
    const viewDetailsButtons = document.querySelectorAll('.clm-view-details-btn');
    viewDetailsButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            const courseId = this.getAttribute('data-course-id');
            const subAccountsSection = document.getElementById('sub-accounts-' + courseId);

            if (subAccountsSection) {
                // Toggle the visibility of the sub-accounts section
                if (subAccountsSection.style.display === 'none' || subAccountsSection.style.display === '') {
                    subAccountsSection.style.display = 'block';
                    subAccountsSection.scrollIntoView({ behavior: 'smooth' });
                    this.textContent = 'Hide Details';
                    this.setAttribute('aria-expanded', 'true');
                } else {
                    subAccountsSection.style.display = 'none';
                    this.textContent = 'View Details';
                    this.setAttribute('aria-expanded', 'false');
                }
            } else {
                console.error('Sub-accounts section not found for course ID:', courseId);
            }
        });
    });
}


if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }

});




        </script>
        <?php
    } else {
        echo '<p>' . __('You do not have permission to view this page.', 'clm') . '</p>';
    }
}

function display_course_details($course_id, $license_data, $user_id) {
    $total_licenses = $license_data['total'];
    $used_licenses = $license_data['used'];
    $remaining_licenses = $total_licenses - $used_licenses;
    $course_title = get_the_title($course_id);

    // Start Course Card
    echo '<div class="clm-course-card" id="course-' . esc_attr($course_id) . '">';
    echo '<h2>' . esc_html($course_title) . '</h2>';
    echo '<p>' . sprintf(__('Total Licenses: %d', 'clm'), $total_licenses) . '</p>';
    echo '<p>' . sprintf(__('Assigned Licenses: %d', 'clm'), $used_licenses) . '</p>';
    echo '<p>' . sprintf(__('Remaining Licenses: %d', 'clm'), $remaining_licenses) . '</p>';

    // View Details Button\
    echo '<div class="clm-button-container">';
    echo '<button class="clm-view-details-btn" 
                 aria-expanded="false" 
                 aria-controls="course-details-' . esc_attr($course_id) . '" 
                 data-course-id="' . esc_attr($course_id) . '" 
                 data-course-title="' . esc_attr($course_title) . '">' . __('View Details', 'clm') . '</button>';

    // Add form to assign licenses
    if ($remaining_licenses > 0) {
        echo '<button class="clm-add-user-btn" data-course-id="' . esc_attr($course_id) . '" data-course-title="' . esc_attr($course_title) . '">' . __('Add User', 'clm') . '</button>';
    } else {
        echo '<p>' . __('No licenses remaining to assign.', 'clm') . '</p>';
    }
    echo '</div>';
    echo '</div>';  // End of .clm-course-card

    render_sub_accounts_table($course_id, $user_id, $course_title);

    // Render the sub-accounts table for the first course
}
function render_sub_accounts_table($course_id, $user_id, $course_title) {
    $sub_accounts = clm_get_sub_accounts($user_id, $course_id);

    echo '<div class="clm-sub-accounts-wrapper" id="sub-accounts-' . esc_attr($course_id) . '">';
    echo '<h3 id="sub-accounts-title">' . esc_html($course_title) . ' Sub Accounts</h3>';
    echo '<table class="clm-course-details-table" style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th style="border: 1px solid #ddd; padding: 8px;">First Name</th>
                    <th style="border: 1px solid #ddd; padding: 8px;">Last Name</th>
                    <th style="border: 1px solid #ddd; padding: 8px;">User Email</th>
                    <th style="border: 1px solid #ddd; padding: 8px;">Registered On</th>
                </tr>
            </thead>
            <tbody id="sub-accounts-tbody-' . esc_attr($course_id) . '">';

    if (!empty($sub_accounts)) {
        foreach ($sub_accounts as $sub_account) {
            echo '<tr>
                    <td style="border: 1px solid #ddd; padding: 8px;">' . esc_html($sub_account->first_name) . '</td>
                    <td style="border: 1px solid #ddd; padding: 8px;">' . esc_html($sub_account->last_name) . '</td>
                    <td style="border: 1px solid #ddd; padding: 8px;">' . esc_html($sub_account->user_email) . '</td>
                    <td style="border: 1px solid #ddd; padding: 8px;">' . esc_html(date('Y-m-d', strtotime($sub_account->user_registered))) . '</td>
                </tr>';
        }
    } else {
        echo '<tr>
                <td colspan="4" style="border: 1px solid #ddd; padding: 8px; text-align: center;">No sub-accounts found.</td>
            </tr>';
    }

    echo '</tbody></table>';
    echo '</div>';  // End of clm-sub-accounts-wrapper
}

// Handle the form submission and log errors
add_action('init', 'clm_handle_license_assignment');

function clm_handle_license_assignment() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'clm_assign_license') {
        if (!clm_verify_nonce()) {
            return;
        }

        $course_id = sanitize_text_field($_POST['clm_course_id']);
        $first_name = sanitize_text_field($_POST['clm_user_first_name']);
        $last_name = sanitize_text_field($_POST['clm_user_last_name']);
        $email = sanitize_email($_POST['clm_user_email']);

        if (!clm_validate_email($email)) {
            return;
        }

        $user = clm_get_or_create_user($email, $first_name, $last_name);

        if (!$user) {
            return;
        }

        if (clm_is_user_already_enrolled($user->ID, $course_id)) {
            clm_show_message('error', __('User is already Enrolled to the Course.', 'clm'));
            return;
        }

        clm_assign_course_to_user($user->ID, $course_id);
    }
}


// Function to get sub-accounts


// Function to display success or error messages in a dialog
function clm_show_message($type, $message) {
    ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const messageType = '<?php echo esc_js($type); ?>';
            const messageText = '<?php echo esc_js($message); ?>';

            const dialogContent = `
                <div class="clm-dialog-overlay clm-unique-dialog" tabindex="-1" role="dialog" aria-labelledby="clm-dialog-title" aria-describedby="clm-dialog-desc" aria-modal="true">
                    <div class="clm-dialog" role="document">
                        <h2 id="clm-dialog-title">${messageType === 'success' ? 'Success: Course Assigned' : 'Error: Course Assign Failed'}</h2>
                        <p id="clm-dialog-desc" aria-live="assertive">${messageText}</p>
                        <button id="clm-close-dialog-btn" aria-label="Close Dialog">Close</button>
                    </div>
                </div>
            `;

            document.body.insertAdjacentHTML('beforeend', dialogContent);

            const dialogOverlay = document.querySelector('.clm-dialog-overlay.clm-unique-dialog');
            const closeButton = document.getElementById('clm-close-dialog-btn');

            closeButton.focus();

            // Trap focus inside the dialog
            dialogOverlay.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    closeDialog();
                }

                const focusableElements = dialogOverlay.querySelectorAll('button');
                const firstFocusableElement = focusableElements[0];
                const lastFocusableElement = focusableElements[focusableElements.length - 1];

                if (e.key === 'Tab') {
                    if (e.shiftKey) { // Shift + Tab
                        if (document.activeElement === firstFocusableElement) {
                            e.preventDefault();
                            lastFocusableElement.focus();
                        }
                    } else { // Tab
                        if (document.activeElement === lastFocusableElement) {
                            e.preventDefault();
                            firstFocusableElement.focus();
                        }
                    }
                }
            });

            // Close dialog function
            function closeDialog() {
                dialogOverlay.remove();
            }

            closeButton.addEventListener('click', closeDialog);

            // Dialog-specific styling
            const dialogStyle = document.createElement('style');
            dialogStyle.textContent = `
                .clm-unique-dialog {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background-color: rgba(0, 0, 0, 0.7);
                    
                    z-index: 1000;
                }

                .clm-unique-dialog .clm-dialog {
                    background: #fff;
                    border-radius: 8px;
                    max-width: 500px;
                    width: 100%;
                    padding: 20px;
                    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                    text-align: left;
                    border: 1px solid lightgrey;
                    position: relative;
                }

                .clm-unique-dialog .clm-dialog h2 {
                    margin-top: 0;
                    font-size: 1em !important;
                    color: ${messageType === 'success' ? '#28a745' : '#dc3545'};
                    font : Caption;
                    text-align: left;
                }

                .clm-unique-dialog .clm-dialog p {
                    margin-top : -20px;
                    font-size: 1em;
                    color: #666;
                    margin-bottom: 20px;
                }

                .clm-unique-dialog #clm-close-dialog-btn {
                    background-color: #004078;
                    color: #fff;
                    border: none;
                    padding: 10px 20px;
                    font-size: 1em;
                    border-radius: 5px;
                    cursor: pointer;
                }

                .clm-unique-dialog #clm-close-dialog-btn:hover {
                    background-color: #002a50;
                }
            `;
            document.head.appendChild(dialogStyle);
        });
    </script>
    <?php
}
