<?php
// Create the "Company" role with specific permissions
function clm_create_company_role() {
    add_role(
        'company',
        __('Company', 'clm'),
        [
            'read' => true,
            'manage_sensei_users' => true,
        ]
    );
}

// Create necessary pages
function clm_create_pages() {
    if (!get_page_by_path('manage-accounts')) {
        $manage_page_id = wp_insert_post([
            'post_title'    => 'Manage Accounts',
            'post_content'  => '[clm_company_manage_accounts]', // Shortcode for managing accounts
            'post_status'   => 'publish',
            'post_type'     => 'page',
            'post_name'     => 'manage-accounts',
        ]);
    }
}


/**
 * Custom function to enroll a user in a course with error handling.
 *
 * @param int $user_id The ID of the user to be enrolled.
 * @param int $course_id The ID of the course in which the user will be enrolled.
 * @return bool True if the user was successfully enrolled, false otherwise.
 * @throws Exception If any error occurs during the enrollment process.
 */
function custom_enroll_user_in_course($user_id, $course_id) {
    try {
        // Check if the user ID and course ID are valid
        if (empty($user_id) || empty($course_id)) {
            throw new Exception('Invalid user ID or course ID provided.');
        }

        // Attempt to start the course for the user
        $result = Sensei_Utils::user_start_course($user_id, $course_id);
        if (!$result) {
            throw new Exception('Failed to start the course for the user.');
        }

        // Attempt manual enrollment
        $manual_enrol = Sensei_Course_Manual_Enrolment_Provider::instance();
        $enrolled = $manual_enrol->enrol_learner($user_id, $course_id);

        if (!$enrolled) {
            throw new Exception('Failed to manually enroll the user in the course.');
        }else{
            clm_send_course_enrollment_email($user_id, $course_id);
        }

        // Return true if everything was successful
        return true;
    } catch (Exception $e) {
        // Log the exception message if logging is required
        error_log('Enrollment Error: ' . $e->getMessage());

        // Return false indicating enrollment failure
        return false;
    }
}


/**
 * Retrieves the sub-accounts associated with a parent user for a specific course.
 *
 * @param int $parent_user_id The ID of the parent user.
 * @param int $course_id The ID of the course.
 * @return WP_User[]|null An array of WP_User objects representing the sub-accounts, or null if an error occurs.
 * @throws Exception If any error occurs during the retrieval process.
 */
/**
 * Retrieves the sub-accounts associated with a parent user for a specific course.
 *
 * @param int $parent_user_id The ID of the parent user.
 * @param int $course_id The ID of the course.
 * @return WP_User[]|null An array of WP_User objects representing the sub-accounts, or null if an error occurs.
 * @throws Exception If any error occurs during the retrieval process.
 */
function clm_get_sub_accounts($parent_user_id, $course_id) {
    try {
        // Validate the parent user ID and course ID
        if (empty($parent_user_id) || empty($course_id)) {
            throw new Exception('Invalid parent user ID or course ID provided.');
        }

        // Fetch all users with relevant meta key
        $args = array(
            'meta_query' => array(
                array(
                    'key' => '_clm_parent_course_data',
                    'compare' => 'EXISTS',
                )
            )
        );
        $users = get_users($args);
        $sub_accounts = [];

        // Loop through users to find those matching the parent and course ID
        foreach ($users as $user) {
            $parent_course_data = get_user_meta($user->ID, '_clm_parent_course_data', true);

            if (is_array($parent_course_data)) {
                foreach ($parent_course_data as $entry) {
                    if ($entry['parent_id'] == $parent_user_id && $entry['course_id'] == $course_id) {
                        $sub_accounts[] = $user;
                        break;
                    }
                }
            }
        }

        if (empty($sub_accounts)) {
            throw new Exception('No sub-accounts found for the provided parent user ID and course ID.');
        }

        return $sub_accounts;
    } catch (Exception $e) {
        // Log any exception messages
        error_log('Sub-Accounts Retrieval Error: ' . $e->getMessage());

        // Return null indicating failure to retrieve sub-accounts
        return null;
    }
}


function clm_verify_nonce() {
    if (!wp_verify_nonce($_POST['_clm_nonce'], 'clm_assign_license_nonce')) {
        error_log('CLM Error: Security check failed.');
        clm_show_message('error', __('Security check failed', 'clm'));
        return false;
    }
    return true;
}


function clm_validate_email($email) {
    if (!is_email($email)) {
        error_log('CLM Error: Invalid email address - ' . $email);
        clm_show_message('error', __('Invalid email address', 'clm'));
        return false;
    }
    return true;
}

function clm_get_or_create_user($email, $first_name, $last_name) {
    $user = get_user_by('email', $email);

    if (!$user) {
        $user_id = wp_create_user($email, wp_generate_password(12, false), $email);

        if (is_wp_error($user_id)) {
            error_log('CLM Error: Failed to create user - ' . $user_id->get_error_message());
            clm_show_message('error', __('Failed to create user', 'clm'));
            return false;
        }

        wp_update_user([
            'ID' => $user_id,
            'first_name' => $first_name,
            'last_name' => $last_name
        ]);

        $current_user_id = get_current_user_id();
        update_user_meta($user_id, '_clm_parent_user', $current_user_id);

        $user = get_user_by('id', $user_id);
        error_log('CLM Info: New user created with ID - ' . $user_id);

        wp_new_user_notification($user_id, null, 'user');
    } else {
        $current_user_id = get_current_user_id();
        if (!get_user_meta($user->ID, '_clm_parent_user', true)) {
            update_user_meta($user->ID, '_clm_parent_user', $current_user_id);
        }
    }

    return $user;
}

function clm_is_user_already_enrolled($user_id, $course_id) {

    $course_started = Sensei_Utils::has_started_course($course_id, $user_id);
    
    
    if ($course_started) {
        error_log('CLM Notice: User ID ' . $user_id . ' has started Course ID ' . $course_id);
        return true;
    } else {
        error_log('CLM Info: User ID ' . $user_id . ' has not started Course ID ' . $course_id);
        return false;
    }
    
}

function clm_assign_course_to_user($user_id, $course_id) {
    $enrolled = custom_enroll_user_in_course($user_id, $course_id);

    if ($enrolled) {
        $current_user_id = get_current_user_id();
        $licenses = get_user_meta($current_user_id, '_clm_licenses', true);
        $licenses[$course_id]['used'] += 1;
        update_user_meta($current_user_id, '_clm_licenses', $licenses);

        // Retrieve the existing parent-course metadata
        $parent_course_data = get_user_meta($user_id, '_clm_parent_course_data', true);

        if (!is_array($parent_course_data)) {
            $parent_course_data = [];
        }

        // Append the new parent-course assignment
        $parent_course_data[] = [
            'parent_id' => $current_user_id,
            'course_id' => $course_id,
        ];

        // Update the user meta with the new array
        update_user_meta($user_id, '_clm_parent_course_data', $parent_course_data);

        error_log('CLM Info: License assigned to user ID ' . $user_id . ' for course ID ' . $course_id);
        clm_show_message('success', __('License successfully assigned.', 'clm'));
    } else {
        error_log('CLM Error: Failed to assign the license to user ID ' . $user_id . ' for course ID ' . $course_id);
        clm_show_message('error', __('Failed to assign the license.', 'clm'));
    }
}


function clm_add_licenses($user_id, $course_id, $quantity) {
    // Retrieve the licenses from user meta and ensure it's an array
    $licenses = get_user_meta($user_id, '_clm_licenses', true);

    if (!is_array($licenses)) {
        // If the retrieved data is not an array, initialize it as an empty array
        error_log("Warning: Licenses meta for user ID {$user_id} was not an array or didn't exist. Initializing as a new array.");
        $licenses = [];
    }

    if (!isset($licenses[$course_id])) {
        // Initialize the license data structure for this specific course ID
        $licenses[$course_id] = ['total' => 0, 'used' => 0];
    }

    // Safely add the quantity of licenses to the 'total'
    $licenses[$course_id]['total'] += $quantity;

    // Update the user meta with the updated licenses array
    update_user_meta($user_id, '_clm_licenses', $licenses);
}


function clm_use_license($user_id, $course_id) {
    $licenses = get_user_meta($user_id, '_clm_licenses', true);

    if (isset($licenses[$course_id])) {
        $licenses[$course_id]['used'] += 1;
        update_user_meta($user_id, '_clm_licenses', $licenses);
    }
}


add_action('woocommerce_order_status_processing', 'clm_assign_company_role_after_purchase', 10, 1);
function clm_assign_company_role_after_purchase($order_id) {
    $order = wc_get_order($order_id);
    $user_id = $order->get_user_id();

    // Log the start of the function
    error_log("CLM: Processing order #{$order_id} for user ID {$user_id}");

    if ($user_id) {
        $items = $order->get_items(); // Get the order items
        foreach ($items as $item) {
            $product_id = $item->get_product_id();
            $licenses_count = get_post_meta($product_id, 'Product_License_Count', true);
            $course_id = get_post_meta($product_id, 'Course_ID', true);
            $course_name = get_post_meta($product_id, 'course_name', true);

            if (!$licenses_count || !$course_id || !$course_name) {
                error_log("WCAG CAM Order Processing Error: Missing custom fields for product ID {$product_id}. License Count: {$licenses_count}, Course ID: {$course_id}, Course Name: {$course_name}");
            } else {
                error_log("WCAG CAM Order Processing: Product ID {$product_id}, License Count: {$licenses_count}, Course ID: {$course_id}, Course Name: {$course_name}");
            }

            error_log("CLM: Found product with Course Name '{$course_name}' with {$licenses_count} licenses.");
            if ($licenses_count > 1) {  // Ensure the license count is valid
                $user = new WP_User($user_id);
                // Assign the "Company" role
                $user->set_role('company');
                error_log("Assigned 'company' role to user ID {$user_id}.");
                
                // Add licenses for the purchased course
                clm_add_licenses($user_id, $course_id, $licenses_count);
                // Log the role assignment and license addition
                error_log("Added {$licenses_count} licenses for course '{$course_name}' to user ID {$user_id}.");
            
                // Send email notification
                clm_send_license_email($user_id, $course_id, $licenses_count , $course_name);
            } else {
                // Log the case where no licenses were added
                error_log("No licenses were added because the license count for product '{$course_name}' was {$licenses_count}.");
            }
        }
    } else {
        // Log the case where no user ID is found
        error_log("CLM: No user ID found for order #{$order_id}");
    }
}

// Send email notification with customizable template

function clm_send_license_email($user_id, $course_id, $quantity, $course_name = '') {
    $user = get_user_by('id', $user_id);
    $course_title = !empty($course_name) ? $course_name : get_the_title($course_id);

    // Get settings
    $email_subject_template = get_option('clm_license_email_subject');
    $email_template = get_option('clm_license_email_template');
    $manage_account_url = get_option('clm_manage_accounts_url');
    $site_owner_name = get_option('clm_site_owner_name', 'Kris Rivernberg');
    $site_home_url = get_option('clm_site_home_url', site_url());

    $email_subject = str_replace('{course_name}', $course_title, $email_subject_template);

    // Replace placeholders
    $email_body = str_replace(
        ['{license_count}', '{course_name}', '{manage_account_url}', '{site_owner_name}', '{site_home_url}'],
        [$quantity, $course_title, $manage_account_url, $site_owner_name, $site_home_url],
        $email_template
    );

    // Log email sending
    error_log("CLM: Sending license email to {$user->user_email} for course '{$course_title}' with {$quantity} licenses.");

    // Send email
    wp_mail($user->user_email, $email_subject, $email_body, ['Content-Type: text/html; charset=UTF-8']);
}

function clm_send_course_enrollment_email($user_id, $course_id) {
    $user = get_user_by('ID', $user_id);
    $course_title = get_the_title($course_id);
    $parent_id = get_user_meta($user_id, '_clm_parent_user', true);
    $parent_user = get_user_by('ID', $parent_id);
    $parent_name = $parent_user ? $parent_user->display_name : 'Your Parent';

    // Get settings
    $email_subject_template = get_option('clm_enrollment_email_subject');
    $email_template = get_option('clm_enrollment_email_template');
    $site_url = get_option('clm_site_home_url', site_url('/my-courses'));
    $site_owner_name = get_option('clm_site_owner_name', 'Kris Rivernberg');
    $site_home_url = get_option('clm_site_home_url', site_url());

    // Generate a password reset link
    $reset_key = get_password_reset_key($user);
    if (!is_wp_error($reset_key)) {
        $reset_url = network_site_url("wp-login.php?action=rp&key=$reset_key&login=" . rawurlencode($user->user_login), 'login');
    } else {
        error_log('CLM Error: Failed to generate password reset link - ' . $reset_key->get_error_message());
        $reset_url = '#'; // Fallback URL if reset link generation fails
    }

    $email_subject = str_replace('{course_name}', $course_title, $email_subject_template);

    // Replace placeholders
    $email_body = str_replace(
        ['{user_name}', '{course_name}', '{user_login}', '{password}', '{reset_url}', '{site_url}', '{parent_name}', '{site_owner_name}', '{site_home_url}'],
        [$user->first_name, $course_title, $user->user_login, '******', $reset_url, $site_url, $parent_name, $site_owner_name, $site_home_url],
        $email_template
    );

    // Send the email
    wp_mail($user->user_email, $email_subject, $email_body, ['Content-Type: text/html; charset=UTF-8']);
}






function clm_remove_user_from_course() {
    if (isset($_GET['user_id']) && isset($_GET['course_id']) && isset($_GET['parent_id'])) {
        $user_id = intval($_GET['user_id']);
        $course_id = intval($_GET['course_id']);
        $parent_id = intval($_GET['parent_id']);

        error_log("Starting course removal process for user_id: $user_id, course_id: $course_id, parent_id: $parent_id");
        // 1. Remove the user from the course
        $course_enrolment = Sensei_Course_Enrolment::get_course_instance( $course_id );
		$result = $course_enrolment->withdraw( $user_id );
        Sensei_Utils::sensei_remove_user_from_course($course_id, $user_id);

        if ($result) {
            error_log("User ID $user_id successfully withdrawn from course ID $course_id");

            // 2. Update the license count for the parent user
            $licenses = get_user_meta($parent_id, '_clm_licenses', true);

            if (isset($licenses[$course_id])) {
                $licenses[$course_id]['used'] -= 1;
                update_user_meta($parent_id, '_clm_licenses', $licenses);
                error_log("License count updated for parent ID $parent_id and course ID $course_id");

                // 3. Remove the course association from the sub-account's metadata
                $parent_course_data = get_user_meta($user_id, '_clm_parent_course_data', true);

                if (is_array($parent_course_data)) {
                    error_log("Current parent course data for user ID $user_id: " . print_r($parent_course_data, true));

                    // Filter out the removed course from the metadata
                    $updated_data = array_filter($parent_course_data, function($entry) use ($course_id, $parent_id) {
                        return !($entry['course_id'] == $course_id && $entry['parent_id'] == $parent_id);
                    });

                    update_user_meta($user_id, '_clm_parent_course_data', $updated_data);
                    error_log("Updated parent course data for user ID $user_id: " . print_r($updated_data, true));
                } else {
                    error_log("No parent course data found for user ID $user_id");
                }

                // Success message
                add_action('admin_notices', function() {
                    echo '<div class="notice notice-success is-dismissible"><p>' . __('User has been withdrawn from the course, the license has been restored, and the sub-account has been updated.', 'clm') . '</p></div>';
                });
            } else {
                error_log("License data not found for parent ID $parent_id and course ID $course_id");
            }
        } else {
            // Error message if withdrawal failed
            error_log("Failed to withdraw user ID $user_id from course ID $course_id");
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible"><p>' . __('Failed to withdraw the user from the course.', 'clm') . '</p></div>';
            });
        }

        // 4. Redirect back to the Course Details page
        wp_redirect(admin_url('admin.php?page=clm-course-details&course_id=' . $course_id . '&parent_id=' . $parent_id));
        exit;
    } else {
        error_log("Missing required parameters: user_id, course_id, or parent_id");
    }
}
add_action('admin_post_clm_remove_user', 'clm_remove_user_from_course');




