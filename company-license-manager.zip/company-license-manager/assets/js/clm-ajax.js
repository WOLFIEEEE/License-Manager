jQuery(document).ready(function($) {
    // Handle the View Details button click
    $('.view-details-button').on('click', function(event) {
        event.preventDefault();

        var requestUrl = $(this).data('url'); // Get the URL from the data-url attribute

        $.ajax({
            url: requestUrl,
            method: 'GET',
            success: function(response) {
                // Extract the specific content you want to replace
                var newContent = $(response).find('.wrap').html();

                // Replace the current content with the new content
                $('.wrap').html(newContent);

                // Optionally, update the browser's history state
                window.history.pushState(null, '', requestUrl);
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
                alert('Failed to load the page.');
            }
        });
    });

    // Handle the Back to Company Details link click
    $('#back-to-company-details').on('click', function(event) {
        event.preventDefault();

        var requestUrl = $(this).data('url'); // Get the URL from the data-url attribute

        $.ajax({
            url: requestUrl,
            method: 'GET',
            success: function(response) {
                // Extract the specific content you want to replace
                var newContent = $(response).find('.wrap').html(); 

                // Replace the current content with the new content
                $('.wrap').html(newContent);
                
                // Optionally, update the browser's history state
                window.history.pushState(null, '', requestUrl);
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
                alert('Failed to load the page.');
            }
        });
    });

    // Handle the Back to Account Details link click
    $('#back-to-account-details').on('click', function(event) {
        event.preventDefault();

        var requestUrl = $(this).data('url'); // Get the URL from the data-url attribute

        $.ajax({
            url: requestUrl,
            method: 'GET',
            success: function(response) {
                // Extract the specific content you want to replace
                var newContent = $(response).find('.wrap').html();

                // Replace the current content with the new content
                $('.wrap').html(newContent);
                
                // Optionally, update the browser's history state
                window.history.pushState(null, '', requestUrl);
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
                alert('Failed to load the page.');
            }
        });
    });

    // Handle the browser's back/forward buttons
    window.onpopstate = function(event) {
        location.reload(); // Reload the page when the back/forward button is used
    };
});
